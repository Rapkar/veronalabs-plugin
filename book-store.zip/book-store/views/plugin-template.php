<?php

echo 'pok';
?>